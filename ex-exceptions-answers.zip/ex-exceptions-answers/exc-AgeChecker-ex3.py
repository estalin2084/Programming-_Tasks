isAgeValid = False

name = input("Please enter your name:")
print("Hello, " + name + "!")

while not(isAgeValid):
    try:        
        age = int(input("Please enter your age:"))
       
        if age > 0 and age < 10:
            print("There are no games available for " + str(age) + " years olds at this time.")            
            isAgeValid = True

        elif age >= 10:
            print("To view the games available for " + str(age) + " year olds, press the 'List the available games' button.") 
            isAgeValid = True
            
        # the age entered is less than 0
        else:           
            print("You have entered an invalid value for age. Try again, this time enter a value greater than zero.")   
                 
    except:
        print("You have entered an invalid value for age. Try again, this time enter a number...")