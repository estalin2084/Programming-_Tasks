while True:
    try:
        # attempting to convert to float a string representing a non-numeric value will result 
        # in a ValueError Exception type being thrown
        width = float(input("Enter window width: "))   
        height = float(input("Enter window height: "))

        break

    # this will catch the error thrown due to a non-numeric value being entered by user               
    except Exception:
        print("Invalid value. Please enter a numeric value for both width and height.")

    
# multipying by 3.28 to convert wood length from meters to feet, 
# since it is is expressed in feet usually
woodLength = 2 * (width + height) * 3.28

# multiply area * 2 to account for double panes of glass
glassArea = 2 * (width * height)

print("The length of the wood needed is " + str(woodLength) + " feet.")   
print("The area of the glass needed is " + str(glassArea) + " square metres.")