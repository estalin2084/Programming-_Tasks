name = input("Enter your name:")
age = int(input("Enter your age:"))

if age > 0 and age < 10:
    print("There are no games available for " + str(age) + " years olds at this time.")  

elif age >= 10:
    print("To view the games available for " + str(age) + " year olds, press the 'List the available games' button.") 

# the age entered is less than 0
else:           
    print("You have entered an invalid value for age. Try again, this time enter a value greater than zero.")