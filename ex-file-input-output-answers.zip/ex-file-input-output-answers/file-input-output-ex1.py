# The program takes input from user, regarding his favourites... (day, season, food, colours)
# The information is then displayed back to the user, as well as written to a text file. 
# User is informed where on the host computer to find the file.
#
import os

filePath = "favourites.txt"             #name of the file to use; in the current working directory   
favColours = []                         

print("Hi!")

# Taking input from user
favDay = input("Please enter your favourite day in a week: ")
favSeason = input("Please enter your favourite season: ")
favFood = input("Please enter your favourite food: ")

#Taking input re: three favourite colours
print("Please enter your 3 favourite colors...")

i = 1
while i <= 3:

    favColours.append(input("- Color {}: ".format(i)))
    i += 1

# Informaing the user where to find the file with the information shared.
print("\n\nThank you!")
print("The following is what you shared about yourself.")
print("The information has also been saved to a file on your computer, here:\n\n\t{}\n\n".format(os.path.join(os.getcwd(), filePath)))

# building the output that is to be displayed on the console, and written to the file
output = ""
output += "Your favourite day is: {}.".format(favDay)
output += "\nYour favourite season is: {}.".format(favSeason)
output += "\nYour favourite food is: {}.".format(favFood)

# using the string join() method to concatenate the List values in a string, using comma as the delimieter in the string
aStringOfColours = ", ".join(favColours)

output += "\nYour favourite colours are: "
output += aStringOfColours
output += ".\n\n"

# printing the output to the console
print(output)

# writing the output to the indicated file
# the file will be created (if does not exist already) in the current working dir
with open(filePath, 'w') as outputFile:
    outputFile.write(output)